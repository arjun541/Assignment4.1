package com.a;

public class ClassA {

	protected int method(int a,int b)
	{
		//System.out.println();
		return a+b;
	}
}
