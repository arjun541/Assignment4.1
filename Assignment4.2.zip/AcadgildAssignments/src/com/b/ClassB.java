package com.b;

import com.a.ClassA;

public class ClassB {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ClassA a=new ClassA();
		int sum=a.method(1, 3);//you can not invoke a method in another package class if it is declared as protected
		System.out.println("value returned by protected method ");

	}

}
